#include "cPrimZahl.h"

int main() {

	char input;
	//cPrimZahl primzahl(rand() % 10000); int i;
	cPrimZahl primzahl; int i;
	do {
		cout << "Primzahl ist " << primzahl << endl;
		cout << "> ";
		cin >> input;
		switch (input) {
		case '+':
			++primzahl;
			cout << "Nach ++primzahl" << endl;
			cout << primzahl;
			break;
		case '-':
			--primzahl;
			cout << "Nach --primzahl" << endl;
			cout << primzahl;
			break;
		case 's':
			cout << "Geben Sie eine Zahl: ";
			cin >> i;
			cout << "primzahl[" << i << "] = " << primzahl[i] << endl;
		default:
			cout << "Unbekanntes Kommando." << endl;
			break;
		}
	} while (input != 'e');

	return 0;
}
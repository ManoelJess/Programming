#include "cJukebox.h"
using namespace std;

int main() {

	cJukebox jukebox1(300);
	int i, index;
	i = jukebox1[37];
	cout << "Subskriptionsergebnis: " << i << endl;
	cout << "Subskriptionsergebnis: " << jukebox1[278] << endl;

	do {
		cout << "Geben Sie einen Titel-Index ein (1-300): ";
		cin >> index;
		i= jukebox1[index];
		cout << "Rueckgabewert: " << i << endl;
	} while (index != 222);


	return 0;
}
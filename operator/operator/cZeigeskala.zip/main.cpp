#include "cLageSkala.h"

int main() {
	/*cLageSkala s1(42, 58, 100);
	cout << s1 << endl;

	cLageSkala s2;
	s2= ++s1;
	cout << "++s2\n" << s2 << endl;
	
	cLageSkala s4(42, 58, 100);
	cLageSkala s3;
	s3 = --s4;
	cout << "--s4\n" << s3 << endl;*/

	cLageSkala s1;
	cout << "Ausgabemethode:" << endl;
	s1.ausgabe();

	cout << "Ausgabeoperator:" << endl;
	cout << s1 << endl;
	
	++s1; ++s1; ++s1;
	cout << "Dreimal ++s1" << endl;
	cout << s1 << endl;
	
	cout << "Ueberladenen Operator >>:" << endl;
	cin >> s1;
	cout << "Nach Eingabe, Ausgabe mit der Ausgabemethode:" << endl;
	s1.ausgabe();

	cout << "Nach Eingabe, Ausgabe mit der Ausgabeoperator:" << endl;
	cout << s1 << endl;

	--s1;
	cout << "Nach --s1, Ausgabe mit der Ausgabeoperator:" << endl;
	cout << s1 << endl;

	return 0;
}